# mbit

Extension for Yahboom_mbit_en V3.0.2

## License

MIT

## Supported targets

* for PXT/microbit
(The metadata above is needed for package search.)
